from distutils.core import setup

setup(
    name='TypeReasoner',
    version='0.1',
    packages=['TypeReasoner', 'TypeReasoner.Worker', 'TypeReasoner.Utilities', 'TypeReasoner.RemoteSparql',
              'TypeReasoner.NtripleParser', 'TypeReasoner.ProcessManager'],
    url='',
    license='',
    author='Thomas Weißgerber',
    author_email='weissger@fim.uni-passau.de',
    description=''
)
