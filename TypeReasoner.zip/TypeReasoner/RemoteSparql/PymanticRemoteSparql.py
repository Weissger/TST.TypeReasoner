from .AbstractRemoteSparql import AbstractRemoteSparql

__author__ = 'tmy'


class PymanticRemoteSparql(AbstractRemoteSparql):
    def __init__(self, server):
        pass

    def get_parents_recursive(self, rdf_type):
        pass

    def get_parents(self, rdf_type):
        pass