__author__ = 'tmy'


class NtripleParser():
    def __init__(self, separator):
        self.separator = separator

    def parse_subject(self, line):
        subject = line.split(self.separator, 1)[0].strip()[1:-1]
        if subject.startswith("#"):
            return None
        else:
            return subject

    def get_triple(self, line):
        split_line = line.split(self.separator)
        if split_line[0].strip().startswith("#"):
            return None
        else:
            return {"subject": split_line[0].strip()[1:-1], "predicate": split_line[1].strip(),
                    "object": split_line[2].strip()[1:-2]}
